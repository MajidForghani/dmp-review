# Literature search and screening audit

This package documents the structured verification and update search conducted on 4 November 2026 for the review of the d-minimal-path problem in multistate flow networks.

## Review design

The manuscript is a critical review supported by a structured verification and update search. Relevant studies had been accumulated over several years through the authors' subject knowledge, publisher and database searches, citation tracing, and author-collected records. The database searches documented here were conducted during revision to verify coverage, identify missed studies, and create a reproducible selection record. They should not be described as the original starting point of a prospectively registered systematic review.

## Sources, fields, and coverage

- Scopus: Article title, Abstract, Keywords
- Web of Science Core Collection: Topic
- IEEE Xplore: All Metadata
- Coverage: database inception to 4 November 2026, with no lower publication-year cutoff
- Search date: 4 November 2026

Records already indexed on the search date with a 2027 final-volume year were retained with that publisher-assigned year.

## Final search expressions

Let `N` be:

> ("multistate flow network" OR "multistate flow networks" OR "multi-state flow network" OR "multi-state flow networks" OR "stochastic flow network" OR "stochastic flow networks" OR "capacitated flow network" OR "capacitated flow networks" OR "capacitated-flow network" OR "capacitated-flow networks" OR "multistate network reliability" OR "multi-state network reliability")

Search A was:

> ("d-minimal path" OR "d-minimal paths" OR "d-minimal-path" OR "d-minimal-paths" OR "d-MP" OR "d-MPs") AND N

Search B was:

> ("minimal capacity vector" OR "minimal capacity vectors" OR "lower boundary vector" OR "lower boundary vectors" OR "lower boundary point" OR "lower boundary points") AND N

The capacitated-flow variants were included after known-item validation showed that they were necessary to retrieve the foundational 1995 paper by Lin, Jane, and Yuan.

## Search and selection counts

| Source | Search A | Search B | Unique within source |
|---|---:|---:|---:|
| Scopus | 37 | 49 | 82 |
| Web of Science Core Collection | 55 | 54 | 106 |
| IEEE Xplore | 6 | 8 | 13 |

- Raw database records: 209
- Unique database records after removing 85 duplicate occurrences: 124
- Eligible database records: 53
- Excluded database records: 71
- Eligible records already present in the accumulated corpus: 37
- Newly retained database records: 16
- Additional eligible records from earlier citation tracing and the authors' accumulated archive: 48
- Final analytical corpus: 101

## Eligibility criteria

The core corpus includes peer-reviewed studies that provide an exact procedure intended to enumerate a complete lower boundary for one demand, for several or all demands, or for a clearly defined generalization. A generalized application was retained when it introduced a distinct successful event, boundary construction, or verification rule relevant to the taxonomy.

Records were excluded when they concerned only d-minimal cuts or binary minimal paths; used approximation, bounds, simulation, or machine learning without exact lower-boundary enumeration; calculated probability or ordering from a boundary assumed to be known; applied an established method without a distinct event, enumeration, or certification contribution; duplicated a fuller study; or fell outside multistate-flow d-MP reliability.

## Deduplication and screening

Exact DOI was used first. Records without a DOI were matched by normalized title, authors, venue, and year. Titles and abstracts were screened first. Remaining records were assessed against the eligibility criteria using the bibliographic record and, where required, the full paper and the authors' existing archive. The workbook contains every unique record, its source presence, the inclusion/exclusion decision, screening stage, and decision reason.

## Package contents

- `exports/`: the six final database exports
- `screenshots/`: screenshots documenting the final result counts and search periods
- `audit/dMP_literature_search_screening_audit.xlsx`: summary, 124 deduplicated records, and record-level screening decisions
- `audit/deduplicated_124.csv`: machine-readable unique-record table
- `audit/screening_decisions.csv`: machine-readable decisions and reasons
- `audit/corpus_metadata_101.csv`: final analytical corpus used to regenerate Figures 1--3

The invalid IEEE advanced-search V2 export is intentionally excluded because its Boolean construction did not represent the intended two-block query.
